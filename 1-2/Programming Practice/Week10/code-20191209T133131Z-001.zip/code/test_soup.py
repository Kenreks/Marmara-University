__author__ = 'acakmak'

import urllib2
from bs4 import BeautifulSoup

c=urllib2.urlopen('http://cs.sehir.edu.tr')
contents=c.read()
print contents


# soup=BeautifulSoup(contents, 'html.parser')
# links=soup.find_all('a')
# print links[5]
# print links[5]['href']




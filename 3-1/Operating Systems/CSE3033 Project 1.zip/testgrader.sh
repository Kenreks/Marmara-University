#!/bin/bash


bash ./myprog1.sh "input.txt"

bash ./myprog2.sh dir1

bash ./myprog3.sh "textfile.txt" lorem merol

bash ./myprog4.sh

bash ./myprog5.sh 5614

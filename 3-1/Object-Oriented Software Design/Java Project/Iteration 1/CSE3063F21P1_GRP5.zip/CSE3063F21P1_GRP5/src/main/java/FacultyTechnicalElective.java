public class FacultyTechnicalElective extends ElectiveCourse{
    public FacultyTechnicalElective(String courseId, String name, int capacity, float credit, float ects) {
        super(courseId, name, capacity, credit, ects);
    }
}

public class NT_UElective extends ElectiveCourse{

    public NT_UElective(String courseId, String name, int capacity, float credit, float ects) {
        super(courseId, name, capacity, credit, ects);
    }
}

from tkinter import *

class MyApp(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.colors = ['red', 'yellow', 'green']
        self.color_index = 0

        self.initUI()

    def initUI(self):
        self.pack(fill=BOTH, expand=True)
        label = Label(self, text = 'Click me to change my color!')
        label.pack(fill=BOTH, expand=True)

        label.bind("<Button-3>", self.on_click)

    def on_click(self, event):
        widget = event.widget
        self.color_index = (self.color_index + 1) % len(self.colors)
        widget.config(bg=self.colors[self.color_index])
        print("clicked at", event.x, event.y)


def main():
    root = Tk()
    root.geometry('300x300+200+200')
    app = MyApp(root)
    root.mainloop()

main()
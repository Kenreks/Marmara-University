from tkinter import *

class MyApp(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.initUI()

    def initUI(self):
        self.pack(fill=BOTH, expand=True)
        label = Label(self, bg="yellow")
        label.pack(fill=BOTH, expand=True)

        label.bind("<Button-1>", self.on_click)

    def on_click(self, event):
        print("clicked at", event.x, event.y)

def main():
    root = Tk()
    root.geometry('300x300+200+200')
    app = MyApp(root)
    root.mainloop()

main()
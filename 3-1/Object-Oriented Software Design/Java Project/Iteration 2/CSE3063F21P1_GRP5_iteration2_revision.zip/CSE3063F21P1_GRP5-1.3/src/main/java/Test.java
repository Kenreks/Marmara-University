public class Test {

    public static void main(String[] args) {
        Simulation simulation = new Simulation();
        simulation.start();
    }
}

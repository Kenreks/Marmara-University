from tkinter import *
class Example(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.initUI()

    def initUI(self):
        self.pack()
        L1 = Label(self, text="User Name")
        L1.pack()
        self.E1 = Entry(self)
        self.E1.pack()

        printButton = Button(self, text='Show entry content',
                             command=self.printSelected)

        printButton.pack()

        self.L2 = Label(self)
        self.L2.pack()

    def printSelected(self):
        self.L2.configure(text=self.E1.get())

def main():
    root = Tk()
    root.geometry("250x150+300+300")
    app = Example(root)
    root.mainloop()

if __name__ == '__main__':
    main()
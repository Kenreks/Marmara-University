# -*- coding: utf-8 -*-
__author__ = 'alicakmak'

import mysearchengine
reload(mysearchengine)

pagelist=['http://sehir.edu.tr/en']

dbtables = {'urllist': 'urllist.db', 'wordlocation':'wordlocation.db',
            'link':'link.db', 'linkwords':'linkwords.db', 'pagerank':'pagerank.db'}

searcher = mysearchengine.searcher(dbtables)
searcher.query('computer')

















#searcher.query(u'şehir üniversitesi')

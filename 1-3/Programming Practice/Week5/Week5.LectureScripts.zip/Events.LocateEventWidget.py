from tkinter import *

class MyApp(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.initUI()

    def initUI(self):
        self.pack(fill=BOTH, expand=True)
        for i in range(20):
            button = Button(self, text=str(i))
            button.pack(fill=BOTH, expand=True)
            button.bind("<Button-1>", self.on_click)

        self.label = Label(self)
        self.label.pack()

    def on_click(self, event):
        widget = event.widget
        self.label["text"] = "You clicked on button " + widget["text"]

def main():
    root = Tk()
    root.geometry('300x300+200+200')
    app = MyApp(root)
    root.mainloop()

main()
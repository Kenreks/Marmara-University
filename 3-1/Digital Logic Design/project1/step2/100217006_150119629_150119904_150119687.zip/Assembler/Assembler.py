# Digital Logic Design 3015 Term Project Step-1 Assembler
# 100217006 Elif Nur Kemiksiz
# 150119629 Hüseyin Kerem Mican
# 150119904 Muhammet Eren Atala
# 150119687 Onur Denizhan Kale

import re
# Instruction Set Architecture opCode table:
opcode = {
"AND":"0001",
"ANDI":"0101",
"OR":"0011",
"ORI":"0111",
"ADD":"0010",
"ADDI":"0110",
"XOR":"0000",
"XORI":"0100",
"JUMP":"1000",
"LD":"1111",
"ST":"1101",
"BEQ":"1010",
"BGT":"1001",
"BLT":"1100",
"BGE":"1011",
"BLE":"1110"
}

def register_to_binary(str):
    #This method converts register's number to binary
    decimal = int(str[1:])
    if(decimal > 15):
        #Register number must be less than 15
        raise ValueError("Register value can not be greater than 15")
    else:
        return ("{0:b}".format(decimal)).zfill(4)
        
def convert_to_machine_code(line):
    #This method gets lines and converts them to related option
    arr = re.split(r'\s|,',line.upper())[:-1]
    numberOfOperands = len(arr)
    isNegative = 0
    try:
        if arr[-1][0] == "-":
            arr[-1] = arr[-1][1:]
            isNegative = 1

        if numberOfOperands == 4:
            #If given number of operand is 4 example: "ADD R1 R2 R3"  
            #It calculates binary result of given instructions :  AND,OR,ADD,XOR,ANDI,ORI,ADDI,XORI,BEQ,BGT,BLT,BGE,BLE

            if arr[-1].isdecimal():
                #It calculates binary result of given instructions : ANDI,ORI,ADDI,XORI,BEQ,BGT,BLT,BGE,BLE
                opcodeString = opcode[arr[0]]
                dest = register_to_binary(arr[1])
                src1 = register_to_binary(arr[2])
                imm = arr[3]

                if isNegative:
                    x = 2**5 - int(imm)
                    imm ="1"+("{0:b}".format(x).zfill(5))
                else:
                    imm=("{0:b}".format(int(imm))).zfill(6)

                result = opcodeString  + dest  + src1 + imm

            else:
                #It calculates binary result of given instructions : AND,OR,ADD,XOR
                opcodeString = opcode[arr[0]]
                dest = register_to_binary(arr[1])
                src1 = register_to_binary(arr[2])
                src2 = register_to_binary(arr[3])
                result = opcodeString + dest + src1 + "00" +src2 
            
        elif numberOfOperands == 3:
            #It calculates binary result of given instructions :  LD or ST
            opcodeString = opcode[arr[0]]
            first = register_to_binary(arr[1])
            addr = arr[2]
            result = opcodeString  + first + ("{0:b}".format(int(addr))).zfill(10)

        elif numberOfOperands == 2: 
            #It calculates binary result of given instruction : JUMP
            opcodeString = opcode[arr[0]]
            addr = arr[1]

            if isNegative:
                x = 2 ** 13 - int(addr)
                addr = "1" + ("{0:b}".format(x).zfill(13))
            else:
                addr = ("{0:b}".format(int(addr))).zfill(14)
            result = opcodeString + addr
    

        hex = f'{int(result.zfill(18),2):X}'
        return hex.zfill(5)
    except UnboundLocalError:
        print("UnboundLocalError")
    except ValueError:
        print("Illegal Argument")
        
def main():
    
    with open('input.txt','r') as inputFile, open('output.txt','w') as outputFile:
        # Open given input and output files
        #tFile.write(f'v2.0 raw\n')

        for line in inputFile.readlines():
            try:
                # Calculate output hexadecimal and write it to "output.txt"
                out = convert_to_machine_code(line)
                outputFile.write(out+f'\n')
            except TypeError :
                print("TypeError")
    inputFile.close()
    outputFile.close()
    return 0


if __name__ == "__main__":
    main()

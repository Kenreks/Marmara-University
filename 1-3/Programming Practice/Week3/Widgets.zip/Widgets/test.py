from Tkinter import *

root = Tk()
root.title('Hello Tkinter')
root.geometry('300x200+100+100')

# we are going to place the main application logic


root.mainloop()
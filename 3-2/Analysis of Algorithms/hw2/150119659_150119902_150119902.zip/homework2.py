counter = 0 #counter variable
colour ={} #dictionary for storing colours
linked_neighbor = {} #dictionary for linked neighbors
temp_ver = [] #list for vertices
max = [] 


#change_colour function provides changes on colour switching 
def change_colour(vertex): 
    for j in range(1000):
        test =0
        for i in range(len(temp_ver[int(vertex)-1])):
            if(j==colour[int(temp_ver[int(vertex)-1][i])-1]):
                test=test+1
        if(test==0):
            if(j>max[0]):
                max[0] = j
            colour[int(vertex)-1]=j
            break

#make_graph function provides help on creating the graph
def make_graph():
    max.append(0)

    for i in range(len(temp_ver)):
        for j in range(len(temp_ver[i])):
            if(colour[i]==colour[int(temp_ver[i][j])-1]):
                change_colour(temp_ver[i][j])

    total_number = max[0]+1
    print(total_number)
    result = " ".join(str(value) for key, value in colour.items())
    print(result)

    #creates a output file and writes output
    with open("output.txt", "a") as f:
        print(total_number, file = f)
        print(result, file= f)

lines = [] # list for lines txt file gets opened in below method
with open('test1.txt') as f:
    lines = f.readlines()

#for loop for writing vertices on lines
linked_neighbor[0] = []

for line in lines:
    counter += 1
    list_string = line.split()

    if(list_string[0]=="p"):

        for i in range(int(list_string[1])):
            temp_ver.append([])
            linked_neighbor[0].append(i+1)
            colour[i] = 0

    else:
        temp_ver[int(list_string[1])-1].append(list_string[2])
        temp_ver[int(list_string[2])-1].append(list_string[1])

#main launch 
make_graph()
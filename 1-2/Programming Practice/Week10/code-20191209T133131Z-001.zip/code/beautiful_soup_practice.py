from bs4 import BeautifulSoup

html_doc = """
<html><head><title>The Dormouse's story</title></head>
<body>
<p class="title"><b>The Dormouse's story</b>
<a href="http://example.com/title1" class="sister" id="link01">title1</a>
<a href="http://example.com/title2" class="sister" id="link02">title2</a>
</p>

<p class="story">Once upon a time there were three little sisters; and their names were
<a href="http://example.com/elsie" class="sister" id="link1">Elsie</a>,
<a href="http://example.com/lacie" class="sister" id="link2">Lacie</a> and
<a href="http://example.com/tillie" class="sister" id="link3">Tillie</a>;
and they lived at the bottom of a well.</p>

<p class="story"><a href="http://example.com/john" class="brother" id="link4">John</a></p>

</body>
</html>
"""

def get_all_links_under(tag):
    return [a["href"] for a in tag.find_all("a")]

root_tag = BeautifulSoup(html_doc, "html.parser")

print get_all_links_under(root_tag), "\n"

print root_tag.body.p.prettify(), "\n"

print root_tag.body.p["class"], "\n"

from bs4 import BeautifulSoup

html_doc = """
<html><head><title>The Dormouse's story</title></head>
<body>
<p class="title"><b>The Dormouse's story</b>
<a href="http://example.com/title1" class="sister" id="link01">title1</a>
<a href="http://example.com/title2" class="sister" id="link02">title2</a>
</p>

<p class="story">Once upon a time there were three little sisters; and their names were
<a href="http://example.com/elsie" class="sister" id="link1">Elsie</a>,
<a href="http://example.com/lacie" class="sister" id="link2">Lacie</a> and
<a href="http://example.com/tillie" class="sister" id="link3">Tillie</a>;
and they lived at the bottom of a well.</p>

<p class="story"><a href="http://example.com/john" class="brother" id="link4">John</a></p>

</body>
</html>
"""

def get_all_links_under(tag):
    return [a["href"] for a in tag.find_all("a")]

root_tag = BeautifulSoup(html_doc, "html.parser")

print get_all_links_under(root_tag), "\n"

print root_tag.body.p.prettify(), "\n"

print root_tag.body.p["class"], "\n"

print root_tag.body.p.b.string, "\n"

print get_all_links_under(root_tag.body.p), "\n"

for tag in root_tag.find_all(class_="story"):
    print get_all_links_under(tag)


print get_all_links_under(root_tag.body.p), "\n"

for tag in root_tag.find_all(class_="story"):
    print get_all_links_under(tag)

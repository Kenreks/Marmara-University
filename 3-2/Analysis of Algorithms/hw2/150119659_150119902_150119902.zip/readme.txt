CONTENTS OF THIS FILE
----------------------


 * Introduction
 * Requirements
 * Recommended modules
 * Installation
 * Configuration
 * Maintainers


INTRODUCTION
------------

The Graph Colouring issue is described as assigning the fewest number of colors to an undirected graph's vertices while ensuring that no consecutive vertices are of the same colour. 
A (correct) k-colouring is one that uses at least k colors. The chromatic number of a graph G is the least number of colours required to colour it (G). 
The aim is to color all of the graph's vertices so that the amount of colors used (k) is as near to the ideal outcome as feasible, i.e. (G). 
Because this issue is NP-Hard, finding the best solution is extremely difficult, especially for big cases.
Many practical issues, such as event scheduling, may be modeled using graph colouring. The program has been written with Python 3. 




Requirements
------------

This module requires the following modules:

* Python Programming language
* Test files 






Recomended Modules
-----------------

* Python 3





Installation
------------

* Open the Python file on Python supported compiler or run it on system's terminal, allow any permission requirements that may be requested by your compiler
* Put the test files in the same workspace as the Python file to make this program run more efficiently





Configuration
-------------

* Set your compiler to Python 3 
* Run the code with names of the test files on the terminal






Maintainers
-----------

Ahmet Faruk Güzel    150119659
Ahmet Aslan 	     150119902
Hüseyin Kerem Mican  150119629

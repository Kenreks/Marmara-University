from tkinter import *
import pickle
import dbm

class SpellChecker(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.initUI(parent)

    def initUI(self, parent):
        self.label_head = Label(self, text = 'Spell Checker App', bg = 'blue', fg = 'white', anchor = CENTER , font = ('', '20', 'bold'))
        self.label_head.pack(fill=X)

        self.label_input_file = Label(self, text = 'Input File Full Path:',font = ('', '14'))
        self.label_input_file.pack(pady = (5,0))

        self.input_entry = Entry(self, width = 50)
        self.input_entry.pack()

        self.dict_path = Label(self, text = 'Dictionary File Full Path:', font = ('','14'))
        self.dict_path.pack(pady = (20,0))

        self.dict_entry = Entry(self, width = 50)
        self.dict_entry.pack()

        self.spell_check_button = Button(self, text = 'Spell Check', font = ('', '12'), command = self.spell_checker)
        self.spell_check_button.pack(pady = (15, 0))

        self.text_label = Text(self, bg = 'white', width = 100, height = 20)
        self.text_label.pack()

    def spell_checker(self):
        self.text_label.tag_configure('Misspelled', background='yellow', foreground='red')
        db = dbm.open(self.dict_entry.get(), 'c')
        open_file = open(self.input_entry.get(), 'r')
        content = open_file.read().splitlines()

        for line in content:
            words = line.split(' ')
            for word in words:
                pickled_word = pickle.dumps(word)

                if pickled_word in db:
                    print('hi')
                    self.text_label.insert(END, word )
                else:
                    print('lol')
                    self.text_label.insert(END, word, 'Misspelled')
                self.text_label.insert(END, ' ')
            self.text_label.insert(END, '\n')


def main():
    root = Tk()
    root.title('Spell Checker')
    root.geometry('800x600')
    app = SpellChecker(root)
    app.pack(fill = BOTH, expand=True)
    root.mainloop()


main()




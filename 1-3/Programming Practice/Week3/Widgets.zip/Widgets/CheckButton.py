
from tkinter import *

class Example(Frame):

    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.initUI()

    def initUI(self):
        self.pack()
        self.var = BooleanVar()
        self.var.set(True)
        self.onClick()
        self.cb = Checkbutton(self, text="Show title: ",
            variable=self.var, command=self.onClick)
        self.cb.pack()

    def onClick(self):
        if self.var.get() == True:
            self.parent.title("Hello Checkbutton!")
        else:
            self.parent.title("")

def main():
    root = Tk()
    root.geometry("450x450+300+300")
    app = Example(root)
    root.mainloop()

if __name__ == '__main__':
    main()
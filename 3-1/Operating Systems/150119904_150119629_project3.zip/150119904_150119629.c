#include <unistd.h>     
#include <sys/types.h>  
#include <errno.h>      
#include <stdio.h>      
#include <stdlib.h>     
#include <pthread.h>    
#include <string.h>     
#include <dirent.h> 
#include <stdbool.h>
#define MAX_LEN 256

/*  
    CSE3033 Operating Systems Project-3
    150119904 Muhammet Eren Atala
    150119629 Hüseyin Kerem Mican

    This program works only if the given number 
    of thread is greater or equal to the number of files.

*/

pthread_mutex_t pmutex;
char** read_directory(char *directory_name);
void* read_files(void* file_path);
void append(char *word_ptr);
bool find_word(char *word_ptr);


struct words{
    char **array;
    int arr_size;
};
struct words word_array;
int word_count = 0;


/* This function reallocates a new memory block for array in given struct*/
void* re_allocate(struct words* word_array){
    if(word_count == 0){
        word_array->array = (char**)malloc(sizeof(char*)*8);
        word_array->arr_size = 8;
        printf("THREAD %lu: Allocated initial array of 8 pointers.\n",pthread_self());
    }
    else{
        word_array->arr_size *= 2;
        word_array->array = (char**)realloc(word_array->array,word_array->arr_size * sizeof(char*));
        printf("THREAD %lu: Re-allocated array of %d pointers.\n",pthread_self(),word_array->arr_size);
    }
}


/* This function search for given word in the word array, 
if it already exists function returns false */
bool find_word(char *word_ptr){
    int index = 0;
    for(index=0;index<word_count;index++){
        if(strcmp(word_array.array[index],word_ptr) == 0){
            printf("THREAD %lu: The word \"%s\" has already located at index %d.\n",pthread_self(),word_ptr,index);
            return false;
        }
    }
    return true;
}

/* This function tries to add given word to the array, if there is no available memory
it reallocates a new memory block */
void append(char *word_ptr){
    pthread_mutex_lock(&pmutex); 
    if(find_word(strtok(word_ptr,"."))){
        word_array.array[word_count] = strtok(word_ptr,".");
        printf("THREAD %lu: Added \"%s\" at index %d.\n",pthread_self(),word_array.array[word_count],word_count);
        word_count++;

    }
    if(word_count == word_array.arr_size){
        re_allocate(&word_array);
    }
    pthread_mutex_unlock(&pmutex);

}

/* Each thread reads dedicated file line by line and seperates them into words
 using this method, then try to add a word to array*/
void* read_files(void* file_path){
    char* path = (char*)malloc(sizeof(char)*50);
    strcpy(path,(char*)file_path);
    FILE* fptr = fopen(path,"r");
    char* line_ptr = (char*)malloc(sizeof(char)*MAX_LEN);

    while(fgets(line_ptr,MAX_LEN,fptr) != NULL){
        char* token;
        char* remainder = strtok(line_ptr,"\n");
        while((token = strtok_r(remainder," ",&remainder)) != NULL ){
            append(token);
        }
    }
    fclose(fptr);
    
}

/* This function reads file names in given directory and puts them in a array*/
char** read_directory(char *directory_name){
    DIR *directory_ptr;
    struct dirent *entry;
    directory_ptr = opendir(directory_name);
    char **files = (char**)malloc(sizeof(char*) * 30);
    
    if(directory_ptr){
        int index=0;
        while((entry = readdir(directory_ptr)) != NULL){
            if(!strcmp(entry->d_name,".")) continue;
            if(!strcmp(entry->d_name,"..")) continue;

            files[index] = (char*)malloc(sizeof(char)*50);
            strcpy(files[index],directory_name);
            strcat(files[index],entry->d_name);
            index++;
        }
        closedir(directory_ptr);
        return files;
    }
}

void main(int argc, char* argv[]){
    char *directory_name = argv[2];
    int total_thread = atoi(argv[4]);
    strcat(directory_name,"/");
    char **files = read_directory(directory_name);
    pthread_t threads[total_thread];
    re_allocate(&word_array);
    pthread_mutex_init(&pmutex, NULL);
    int i=0;
    for(i=0;i<total_thread;i++){
        pthread_create(&threads[i],NULL,read_files,(void*)files[i] );
        printf("MAIN THREAD: Assigned \"%s\" to worker thread %lu.\n",files[i],threads[i]);

    }
    /* Wait for child threads to finish process */
    for(i=0;i<total_thread;i++){
        pthread_join(threads[i],NULL);
    }
    pthread_mutex_destroy(&pmutex);
    

}
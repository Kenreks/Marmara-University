from tkinter import *

root = Tk()
root.geometry('450x750+300+300')
root.title('Hello World')



root.mainloop()
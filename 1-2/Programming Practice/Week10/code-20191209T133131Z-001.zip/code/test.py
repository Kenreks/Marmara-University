from bs4 import BeautifulSoup

# Extract the text from an HTML page (no tags)
def gettextonly(soup):
    v = soup.string
    if v == None:
        c = soup.contents
        resulttext = ''
        for t in c:
            subtext = gettextonly(t)
            resulttext += subtext + '\n'
        return resulttext
    else:
        return v.strip()

html = '<p> engr <b> 212 </b></p>'
soup = BeautifulSoup(html, 'html.parser')
print gettextonly(soup)

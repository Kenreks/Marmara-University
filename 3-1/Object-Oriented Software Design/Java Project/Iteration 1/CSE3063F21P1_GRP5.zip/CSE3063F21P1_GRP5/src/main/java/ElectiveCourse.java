public class ElectiveCourse extends Course{

    public ElectiveCourse(String courseId, String name, int capacity, float credit, float ects) {
        super(courseId, name, capacity, credit, ects);
    }
}

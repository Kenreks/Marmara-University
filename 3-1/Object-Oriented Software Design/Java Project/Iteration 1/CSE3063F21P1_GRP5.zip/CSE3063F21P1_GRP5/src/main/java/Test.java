public class Test {
    public static void main(String[] args) {
        System.out.println("helloWorld");
        System.out.println("in develop");

        Simulation simulation = new Simulation();
        simulation.start();
    }
}

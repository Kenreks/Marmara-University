public class LabCourse extends Course{
    public LabCourse(String courseId, String name, int capacity, float credit, float ects) {
        super(courseId, name, capacity, credit, ects);
    }
}

from tkinter import *
class Example(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.initUI()

    def initUI(self):
        self.pack()
        text = Text(self)
        text.insert(INSERT, "Hello.....")
        text.insert(END, "Bye Bye.....\n")
        # text.window_create(END, window=Button(text, text='Bye'))  # Example 2
        self.photo = PhotoImage(file='horse.png')
        text.image_create(END, image=self.photo)

        text.tag_add("here", "1.0", "1.4")
        text.tag_add("start", "1.8", "1.13")
        text.tag_config("here", background="yellow", foreground="blue")
        text.tag_config("start", background="black", foreground="green")

        text.pack()

def main():
    root = Tk()
    root.geometry("600x600+300+300")
    app = Example(root)
    root.mainloop()

if __name__ == '__main__':
    main()

from tkinter import *
class Example(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.initUI()

    def initUI(self):
        self.pack()
        cities = ['Uskudar', 'Kadikoy', 'Maltepe', 'Kartal']

        self.lb = Listbox(self, selectmode='single')
        for i in cities:
            self.lb.insert(END, i)

        printButton = Button(self, text='Print selected cities',
                             command=self.printSelected)

        self.lb.pack(pady=15)
        printButton.pack()

    def printSelected(self):
        for index in self.lb.curselection():
            print(self.lb.get(index))


def main():
    root = Tk()
    root.geometry("150x300+300+300")
    app = Example(root)
    root.mainloop()

if __name__ == '__main__':
    main()